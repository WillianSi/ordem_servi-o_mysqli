<?php 

require_once("conecta_bd.php");

function consultaStatusUsuario($status){
    $conexao = conecta_db();
    $query = "SELECT count(*) AS total
                FROM ordem
            WHERE status = '$status'";
    $resultado = mysqli_query($conexao,$query);
    $total  = mysqli_fetch_assoc($resultado);
    return $total;
}

function consultaStatusCliente( $cod_usuario,$status){
    $conexao = conecta_db();
    $query = "SELECT count(*) AS total
                FROM ordem
            WHERE cod_cliente='$cod_usuario' and status = '$status'";
    $resultado = mysqli_query($conexao,$query);
    $total  = mysqli_fetch_assoc($resultado);
    return $total;
}

function consultaStatusTerceirizado( $cod_usuario,$status){
    $conexao = conecta_db();
    $query = "SELECT count(*) AS total
                FROM ordem
            WHERE cod_cliente='$cod_usuario' and status = '$status'";
    $resultado = mysqli_query($conexao,$query);
    $total  = mysqli_fetch_assoc($resultado);
    return $total;
}

?>